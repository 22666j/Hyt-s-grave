package dev.ethereal.module.impl.combat;

import dev.ethereal.event.annotations.EventTarget;
import dev.ethereal.event.impl.events.*;
import dev.ethereal.module.Category;
import dev.ethereal.module.Module;
import dev.ethereal.module.impl.render.HUD;
import dev.ethereal.ui.font.FontManager;
import dev.ethereal.utils.*;

import dev.ethereal.utils.player.InventoryUtil;
import dev.ethereal.utils.render.ColorUtil;
import dev.ethereal.utils.render.RenderUtil;
import dev.ethereal.utils.render.RoundedUtil;
import dev.ethereal.utils.render.animation.Animation;
import dev.ethereal.utils.render.animation.AnimationUtils;
import dev.ethereal.utils.render.animation.Direction;
import dev.ethereal.utils.render.animation.impl.DecelerateAnimation;
import dev.ethereal.utils.render.shader.ShaderElement;
import dev.ethereal.value.impl.BoolValue;
import dev.ethereal.value.impl.ModeValue;
import dev.ethereal.value.impl.NumberValue;


import io.netty.buffer.Unpooled;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.Items;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S32PacketConfirmTransaction;

import java.awt.*;
import java.util.LinkedList;

import static dev.ethereal.Client.mc;
import static dev.ethereal.ui.font.FontManager.font18;

public class Gapple extends Module {

    private long eatStartTime = 0;
    private boolean isEating = false;

    private boolean hasEaten = false;
    private final ModeValue modeValue = new ModeValue("Mode", new String[]{"NoC02", "Stuck"}, "Stuck");
    public static ModeValue AutoGappleHUDMode = new ModeValue("RenderMode", new String[]{"Ethereal", "Ethereal2"}, "Ethereal");
    private final NumberValue speed = new NumberValue("Speed", 5, 1, 10, 1);
    private final BoolValue autoDis = new BoolValue("AutoDis", true);

    public Gapple() {
        super("AutoGapple", Category.Player);
    }

    private final Animation anim = new DecelerateAnimation(250, 1);
    private int s;
    private boolean isAutoDis;
    public static boolean isS12;
    private final LinkedList<Packet<?>> packets = new LinkedList<>();
    private final LinkedList<Packet<NetHandlerPlayClient>> p = new LinkedList<>();


    @EventTarget
    public void onEnable() {
        s = 0;
        isAutoDis = false;
        packets.clear();
        p.clear();
    }


    @EventTarget
    public void onDisable() {
        poll();
        takePoll();

        if (isAutoDis) {
            setState(true);
        }
    }


    @EventTarget
    public void onEventRender2D(EventRender2D event) {
        anim.setDirection(getState() ? Direction.FORWARDS : Direction.BACKWARDS);
        if (!getState() && anim.isDone()) return;
        String countStr = String.valueOf(s);
        ScaledResolution sr = new ScaledResolution(mc);
        float x, y;
        float output = (float) anim.getOutput();
        int spacing = 3;
        String text = countStr;
        float textWidth = FontManager.font16.getStringWidth(text + "Eating") + 40;
        float totalWidth = (float) (((textWidth + spacing) + 6) * output + 70);
        x = sr.getScaledWidth() / 2f - (totalWidth / 2f);
        y = sr.getScaledHeight() - (sr.getScaledHeight() / 2f - 20) + 40;
        float height = 20;
        switch (AutoGappleHUDMode.getValue().toLowerCase()) {
            case "ethereal":
                ShaderElement.addBlurTask(() -> {
                    RoundedUtil.drawRound(x + 23, y, totalWidth - 50, height + 25, 4, Color.WHITE);
                });
                ShaderElement.addBloomTask(() -> {
                    RoundedUtil.drawRound(x + 23, y, totalWidth - 50, height + 25, 4, Color.BLACK);
                });
                RenderUtil.scissorStart(x - 1.5, y - 1.5, totalWidth + 3, height + 28);
                RoundedUtil.drawRound(x + 23, y, totalWidth - 50, height + 25, 4, ColorUtil.tripleColor(20, .45f));
                FontManager.font16.drawString(text, x + 35 + spacing + 30, y + FontManager.font16.getMiddleOfBox(height) + 26, -1);
                RenderUtil.scissorEnd();
                RoundedUtil.drawRound(x + 14 + 30, y + FontManager.font16.getMiddleOfBox(height) + 10F, totalWidth - 50 - 42, 5, 1.5f, new Color(0, 0, 0, 60));
                RoundedUtil.drawGradientHorizontal(x + 14 + 30, y + FontManager.font16.getMiddleOfBox(height) + 10F, (totalWidth - 30) * Math.min(Math.max((s / 75f), 0F), 1f), 5, 1.5f, HUD.color(1), HUD.color(6));
                break;
            case "ethereal2":
                RenderUtil.scissorStart(x - 1.5, y - 1.5, totalWidth + 3, height + 28);
                RoundedUtil.drawRound(x + 23, y, totalWidth - 50, height + 25, 4, new Color(35, 34, 34, 250));
                FontManager.font16.drawString(text, x + 35 + spacing + 30, y + FontManager.font16.getMiddleOfBox(height) + 26, -1);
                RenderUtil.scissorEnd();
                RoundedUtil.drawRound(x + 14 + 30, y + FontManager.font16.getMiddleOfBox(height) + 10F, totalWidth - 50 - 42, 5, 1.5f, new Color(0, 0, 0, 60));
                RoundedUtil.drawGradientHorizontal(x + 14 + 30, y + FontManager.font16.getMiddleOfBox(height) + 10F, (totalWidth - 30) * Math.min(Math.max((s / 75f), 0F), 1f), 5, 1.5f, HUD.color(1), HUD.color(6));
        }
    }

    @EventTarget
    public void onPacketSend(PacketSendEvent eventPacketSend) {
        Packet<?> packet = eventPacketSend.getPacket();

        if (modeValue.is("NoC02")) {
            if (packet instanceof C07PacketPlayerDigging || packet instanceof C09PacketHeldItemChange || packet instanceof C0EPacketClickWindow || packet instanceof C0DPacketCloseWindow || packet instanceof C0BPacketEntityAction || packet instanceof C02PacketUseEntity || packet instanceof C0APacketAnimation) {
                eventPacketSend.setCancelled();
                return;
            }

            if (packet instanceof C03PacketPlayer) {
                packets.add(packet);
                eventPacketSend.setCancelled();
            }
        } else if (modeValue.is("Stuck")) {
            if (packet instanceof C01PacketChatMessage || packet instanceof C07PacketPlayerDigging || packet instanceof C09PacketHeldItemChange || packet instanceof C0EPacketClickWindow || packet instanceof C0DPacketCloseWindow) {
                eventPacketSend.setCancelled();
                return;
            }

            if (packet instanceof C03PacketPlayer) {
                this.s++;
            }

            if (!(packet instanceof C08PacketPlayerBlockPlacement)) {
                packets.add(packet);
                eventPacketSend.setCancelled();
            }
        }
    }


    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {

        if (modeValue.is("NoC02")) {

            if (packets.size() > 32) {
                if (getApple() > 0) {
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C09PacketHeldItemChange(getApple()));
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getStackInSlot(getApple())));
                    takePoll();
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                    if (autoDis.getValue()) {
                        isAutoDis = true;
                        setState(false);
                    }
                    else {
                        poll();
                        packets.clear();
                    }
                }
            }
        } else if (modeValue.is("Stuck")) {
            if (getApple() > 0) {
                if (this.s > 33) {
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C09PacketHeldItemChange(getApple()));
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getStackInSlot(getApple())));
                    takePoll();
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));

                    if (autoDis.getValue()) {
                        isAutoDis = true;
                        setState(false);
                    }
                    else this.s = 0;
                } else {
                    if (mc.thePlayer.ticksExisted % speed.getValue().intValue() == 0) {
                        while (!packets.isEmpty()) {
                            Packet<?> packet = packets.poll();

                            if (packet instanceof C01PacketChatMessage) break;

                            if (packet instanceof C03PacketPlayer) {
                                this.s--;
                            }

                            mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(packet);
                        }
                    }
                }
            } else {
                DebugUtil.log("No Apple");
                setState(false);
            }
        }
    }


    @EventTarget
    public void onMotion(EventMotion eventMotion) {
        if (eventMotion.isPost()) {
            packets.add(new C01PacketChatMessage("sb"));
        }
    }


    @EventTarget
    public void onSlow(EventSlowDown eventSlowDown) {
        eventSlowDown.setCancelled(false);
        eventSlowDown.setForwardMultiplier(0.2f);
        eventSlowDown.setStrafeMultiplier(0.2f);
    }


    @EventTarget
    public void onPacket(PacketReceiveEvent eventPacketReceive) {
        Packet<?> packet = eventPacketReceive.getPacket();

        if (modeValue.is("NoC02")) {
            if (packet instanceof S12PacketEntityVelocity s12PacketEntityVelocity && s12PacketEntityVelocity.getEntityID() == mc.thePlayer.getEntityId()) {
                p.add((Packet<NetHandlerPlayClient>) packet);
                eventPacketReceive.setCancelled();
            }

            if (packet instanceof S32PacketConfirmTransaction) {
                p.add((Packet<NetHandlerPlayClient>) packet);
                eventPacketReceive.setCancelled();
            }
        } else if (modeValue.is("Stuck")) {
            if (packet instanceof S12PacketEntityVelocity s12PacketEntityVelocity && s12PacketEntityVelocity.getEntityID() == mc.thePlayer.getEntityId()) {
                isS12 = true;
            }
        }
    }

    private int getApple() {
        int e = -1;
        for (int i = 0; i < 9; i++) {
            if (!(mc.thePlayer.inventoryContainer.getSlot(i + 36).getHasStack()) || !(mc.thePlayer.inventoryContainer.getSlot(i + 36).getStack().getItem() instanceof ItemAppleGold)) continue;

            e = i;
        }

        return e;
    }


    private void takePoll() {
        while (!packets.isEmpty()) {
            Packet<?> packet = packets.poll();

            if (packet instanceof C01PacketChatMessage || packet instanceof C07PacketPlayerDigging || packet instanceof C0EPacketClickWindow || packet instanceof C0DPacketCloseWindow) continue;

            mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(packet);
        }
    }


    private void poll() {
        while (!p.isEmpty()) {
            p.poll().processPacket(mc.getNetHandler());
        }
    }
}


