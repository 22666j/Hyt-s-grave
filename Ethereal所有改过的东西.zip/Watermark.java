package dev.ethereal.ui.hud.impl;

import dev.ethereal.Client;
import dev.ethereal.ui.font.FontManager;
import dev.ethereal.ui.hud.HUD;
import dev.ethereal.utils.render.ColorUtil;
import dev.ethereal.utils.render.RenderUtil;
import dev.ethereal.utils.render.RoundedUtil;
import dev.ethereal.utils.render.shader.ShaderElement;
import dev.ethereal.value.impl.ModeValue;
import net.minecraft.client.Minecraft;

import java.awt.*;
import java.time.LocalDateTime;

import static dev.ethereal.module.impl.render.HUD.*;

public class Watermark extends HUD {
    public static ModeValue WatermarkMode = new ModeValue("Watermark Mode", new String[]{"Ethereal", "Ethereal2"}, "Ethereal");

    public Watermark() {
        super(50, 20, "Watermark");
    }

    @Override
    public void drawShader() {

    }


    @Override
    public void onTick() {
        String clientName = markTextValue.get();

        if (charIndex > clientName.length()) {
            if (clientName.isEmpty()) {
                charIndex = 0;
            } else {
                charIndex = clientName.length() - 1;
            }
        }

        if (clientName.isEmpty()) {
            return;
        }

        updateTick++;

        if (updateTick > 5) {
            if (charIndex > clientName.length() - 1) {
                backward = true;
            } else if (charIndex <= 0) {
                backward = false;
            }
            if (backward) {
                charIndex--;
            } else {
                charIndex++;
            }

            markStr = clientName.substring(0, charIndex);

            updateTick = 0;
        }
    }
    public double calculateBPS() {
        double bps = (Math.hypot(mc.thePlayer.posX - mc.thePlayer.prevPosX, mc.thePlayer.posZ - mc.thePlayer.prevPosZ) * mc.timer.timerSpeed) * 20;
        return Math.round(bps * 100.0) / 100.0;
    }
    @Override
    public void predrawhud() {
    }

    int updateTick;
    int charIndex;
    boolean backward;
    String markStr;

    @Override
    public void drawHUD(int xPos, int yPos, float partialTicks) {
        switch (WatermarkMode.getValue().toLowerCase()) {
            case "ethereal":
                String clientName = Client.name;
                String mark = markStr;
                LocalDateTime now = LocalDateTime.now();
                int hour = now.getHour();
                int minute = now.getMinute();
                String title = String.format(" |  %s  |  fps:%s  |  %s  |  %s", Client.instance.user, Minecraft.getDebugFPS(), Client.version, hour + ":" + minute);
                float width = FontManager.font18.getStringWidth(title) + FontManager.font18.getStringWidth(clientName) + 8 + 3;
                RoundedUtil.drawRound(4, 5, width + 5, FontManager.font20.getHeight() + 5, 4, new Color(0, 0, 0, 100));
                //blur
                ShaderElement.addBlurTask(() -> RoundedUtil.drawRound(4, 5, width + 5, FontManager.font20.getHeight() + 5, 4, Color.WHITE));
                ShaderElement.addBloomTask(() -> RoundedUtil.drawRound(4, 5, width + 5, FontManager.font20.getHeight() + 5, 4, new Color(0, 0, 0, 255)));

                FontManager.font20.drawString(clientName, 9, 9 + 1, -1);
                FontManager.font18.drawString(title, 9 + FontManager.font20.getStringWidth(clientName) + 2, 9.5f + 1, -1);
                break;
            case "ethereal2":
                float widt = FontManager.icon18.getStringWidth("C");
                float width2 = FontManager.font18.getStringWidth(Client.name);
                RoundedUtil.drawRound(4,5,widt+width2+12,18,3,new Color(35, 34, 34,250));
                FontManager.icon18.drawString("C",8,10.5f, dev.ethereal.module.impl.render.HUD.color(1).getRGB());
                FontManager.font18.drawString(Client.name,11+widt,10.5f, dev.ethereal.module.impl.render.HUD.color(1).getRGB());
                ///////////////////////////////
                float width3 = FontManager.icon18.getStringWidth("U");
                float width4 = FontManager.font18.getStringWidth(mc.getSession().getUsername());

                RoundedUtil.drawRound(4+60,5,width3+width4+12,18,3,new Color(35, 34, 34,250));
                FontManager.icon18.drawString("U",8+60,10.5f, dev.ethereal.module.impl.render.HUD.color(1).getRGB());
                FontManager.font18.drawString(mc.getSession().getUsername(),11+widt+57,11f, Color.WHITE.getRGB());
                ///////////////////////////////
                float width5 = FontManager.icon18.getStringWidth("J");
                float width6 = FontManager.font18.getStringWidth(String.valueOf(Minecraft.getDebugFPS())+"Fps");
                RoundedUtil.drawRound(4+44*2+width4,5,width5+width6+12,18,3,new Color(35, 34, 34,250));
                FontManager.icon18.drawString("J",8+43*2+width4,11.5f, dev.ethereal.module.impl.render.HUD.color(1).getRGB());
                FontManager.font18.drawString(String.valueOf(Minecraft.getDebugFPS())+"Fps",11+widt+42*2+width4,11f, Color.WHITE.getRGB());


        }

    }

}
